Authors
-------

The original author: Steve Menard

Current Maintainer: Luis Nell


Huge thanks to these CONTRIBUTORS:

* lazerscience
* Koblaid
* Michael Willis (michaelwillis)
* awesomescot
* Joe Quant (joequant)
* Mario Rodas
* David Moss
* Stepan Kolesnik
* Philip Smith
* Bastian Bowe
* Kristi
* Martin K. Scherer
* Dongwon Shin
* rbprogrammer
* Karl Einar Nelson
